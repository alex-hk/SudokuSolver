SudokuSolver code

Simple Sudoku solver for practice
